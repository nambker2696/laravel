<!--Start of Tawk.to Script (0.3.1)-->
<script type="text/javascript">
    var Tawk_API=Tawk_API||{};

    Tawk_API.visitor = {
        name  : " ",
        email : ""
    };
    var Tawk_LoadStart=new Date();
    (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/571dc8ee96f68c7e17ef951d/default';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
    })();
</script>

<script type='text/javascript' src='https://s0.wp.com/wp-content/js/devicepx-jetpack.js?ver=201727'></script>
<script type='text/javascript' src='https://secure.gravatar.com/js/gprofiles.js?ver=2017Julaa'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var WPGroHo = {"my_hash":""};
    /* ]]> */
</script>
<script type='text/javascript' src='https://raratheme.com/wp-content/plugins/jetpack/modules/wpgroho.js?ver=4.8'></script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/bootstrap.js?ver=3.3.6'></script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/carousel.js?ver=1.1.2'></script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/jquery.meanmenu.js?ver=2.0.8'></script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/equal-height.js?ver=1.1.2'></script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/sticky-sidebar.js?ver=1.1.2'></script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/scroll-nav.js?ver=3.0.0'></script>
<script type='text/javascript'>
    /* <![CDATA[ */
    var rara_theme_custom = {"ajax_url":"https:\/\/raratheme.com\/wp-admin\/admin-ajax.php","club_nonce":"bf7f62fce2","theme_club":"13123","club_upgrade":"https:\/\/raratheme.com\/checkout\/?club_upgrade"};
    /* ]]> */
</script>
<script type='text/javascript' src='https://raratheme.com/wp-content/themes/rara-theme/js/custom.js?ver=1.1.2'></script>
<script type='text/javascript' src='https://raratheme.com/wp-includes/js/wp-embed.min.js?ver=4.8'></script>
<script type='text/javascript' src='https://stats.wp.com/e-201727.js' async defer></script>
<script type='text/javascript'>
    _stq = window._stq || [];
    _stq.push([ 'view', {v:'ext',j:'1:5.0',blog:'110215225',post:'125',tz:'0',srv:'raratheme.com'} ]);
    _stq.push([ 'clickTrackerInit', '110215225', '125' ]);
</script>
<script type="text/javascript">
    var bwpRecaptchaCallback = function() {
    };
</script>

<script src="https://www.google.com/recaptcha/api.js?onload=bwpRecaptchaCallback&#038;render=explicit" async defer></script>






<script type="text/javascript">
    /* <![CDATA[ */
    var pys_edd_ajax_events = [];
    /* ]]> */
</script>