<div class="promotional-block">
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="img-holder">
          <a href="https://raratheme.com/preview/spa-and-salon-pro/plan/">
            <img src="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/wellness-589776_640-380x226.jpg" alt="" class="hoverZoomLink">
          </a>                                      
          <div class="icon-holder">
            <span class="fa fa-money"></span>
          </div>
        </div>

        <div class="text-holder mCustomScrollbar _mCS_1 mCS-autoHide mCS_no_scrollbar" style="position: relative; overflow: visible;">
          <div id="mCSB_1" class="mCustomScrollBox mCS-minimal mCSB_vertical mCSB_outside" style="max-height: none;" tabindex="0">
            <div id="mCSB_1_container" class="mCSB_container mCS_y_hidden mCS_no_scrollbar_y" style="position:relative; top:0; left:0;" dir="ltr">
              <p>We provide wide range of therapy.</p>									                                                                      
            </div>
          </div>
          <div id="mCSB_1_scrollbar_vertical" class="mCSB_scrollTools mCSB_1_scrollbar mCS-minimal mCSB_scrollTools_vertical" style="display: none;">
            <div class="mCSB_draggerContainer">
              <div id="mCSB_1_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 50px; height: 0px; top: 0px;">
                <div class="mCSB_dragger_bar" style="line-height: 50px;">

                </div>
              </div>
              <div class="mCSB_draggerRail">
              </div>
            </div>
          </div>
        </div>
      </div> 

      <div class="col">
        <div class="img-holder">
          <a href="https://raratheme.com/preview/spa-and-salon-pro/benefits-of-massage/">
            <img src="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/cat-1-380x226.jpg" alt="" class="hoverZoomLink">
          </a>                                      
          <div class="icon-holder">
            <span class="fa fa-thumbs-up"></span>
          </div>
        </div>

        <div class="text-holder mCustomScrollbar _mCS_2 mCS-autoHide" style="position: relative; overflow: visible;">
          <div id="mCSB_2" class="mCustomScrollBox mCS-minimal mCSB_vertical mCSB_outside" style="max-height: 66px;" tabindex="0">
            <div id="mCSB_2_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">
              <strong class="title"><a href="https://raratheme.com/preview/spa-and-salon-pro/benefits-of-massage/">Benefits of Massage</a></strong>									                                  
              <p>Find out why you need to do massage.</p>									                                                                      
            </div>
          </div>
          <div id="mCSB_2_scrollbar_vertical" class="mCSB_scrollTools mCSB_2_scrollbar mCS-minimal mCSB_scrollTools_vertical" style="display: block;">
            <div class="mCSB_draggerContainer">
              <div id="mCSB_2_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 50px; height: 66px; top: 0px; display: block; max-height: 86px;">
                <div class="mCSB_dragger_bar" style="line-height: 50px;">
                </div>
              </div>
              <div class="mCSB_draggerRail">
              </div>
            </div>
          </div>
        </div>
      </div> 

      <div class="col">
        <div class="img-holder">
          <a href="https://raratheme.com/preview/spa-and-salon-pro/shop/">
            <img src="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/spices-997597_1280-1-380x226.jpg" alt="" class="hoverZoomLink">
          </a>                                      
          <div class="icon-holder">
            <span class="fa fa-shopping-cart"></span>
          </div>
        </div>

        <div class="text-holder mCustomScrollbar _mCS_3 mCS-autoHide" style="position: relative; overflow: visible;">
          <div id="mCSB_3" class="mCustomScrollBox mCS-minimal mCSB_vertical mCSB_outside" style="max-height: 66px;" tabindex="0">
            <div id="mCSB_3_container" class="mCSB_container" style="position:relative; top:0; left:0;" dir="ltr">
              <strong class="title"><a href="https://raratheme.com/preview/spa-and-salon-pro/shop/">Buy our products</a></strong>									
              <p>Check out our recommended products.</p>									                                                                      
            </div>
          </div>
          <div id="mCSB_3_scrollbar_vertical" class="mCSB_scrollTools mCSB_3_scrollbar mCS-minimal mCSB_scrollTools_vertical" style="display: block;">
            <div class="mCSB_draggerContainer">
              <div id="mCSB_3_dragger_vertical" class="mCSB_dragger" style="position: absolute; min-height: 50px; height: 66px; top: 0px; display: block; max-height: 86px;">
                <div class="mCSB_dragger_bar" style="line-height: 50px;">
                </div>
              </div>
              <div class="mCSB_draggerRail">
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div>        
  </div>
</div>