<div class="footer-t">
	<div class="container">
		<div class="row">
			<div class="col">
				<section id="text-4" class="widget widget_text"><h2 class="widget-title">About Spa and Salon Pro</h2>			<div class="textwidget">Spa and Salon Pro is a beautifully designed WordPress Theme. The theme can be used to create stunning websites without touching a single line of code. Using the theme, you can easily display your attractive services in a professional manner and make a great impression with the website visitors.
					The theme comes with a wide range of features and functionalities. The theme is also SEO and Speed Optimized.</div>
				</section>
			</div>
			<div class="col">
				<section id="spa_and_salon_facebook_page_widget-5" class="widget widget_spa_and_salon_facebook_page_widget">        
					<div class="spa-and-salon-facebook-page-box">
						<h2 class="widget-title">Our Facebook Page</h2>        
						<div class="fb-page fb_iframe_widget" data-href="https://facebook.com/rarathemehq" data-height="300" data-width="400" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true" data-small-header="true" data-tabs="timeline" fb-xfbml-state="rendered" fb-iframe-plugin-query="adapt_container_width=true&amp;app_id=&amp;container_width=380&amp;height=300&amp;hide_cover=false&amp;href=https%3A%2F%2Ffacebook.com%2Frarathemehq&amp;locale=en_US&amp;sdk=joey&amp;show_facepile=true&amp;small_header=true&amp;tabs=timeline&amp;width=400"><span style="vertical-align: bottom; width: 380px; height: 300px;"><iframe name="f16c41b906c6774" width="400px" height="300px" frameborder="0" allowtransparency="true" allowfullscreen="true" scrolling="no" title="fb:page Facebook Social Plugin" src="https://www.facebook.com/v2.4/plugins/page.php?adapt_container_width=true&amp;app_id=&amp;channel=https%3A%2F%2Fstaticxx.facebook.com%2Fconnect%2Fxd_arbiter%2Fr%2FXBwzv5Yrm_1.js%3Fversion%3D42%23cb%3Df7d2121ad8746%26domain%3Draratheme.com%26origin%3Dhttps%253A%252F%252Fraratheme.com%252Ff3714d5ea3d424%26relation%3Dparent.parent&amp;container_width=380&amp;height=300&amp;hide_cover=false&amp;href=https%3A%2F%2Ffacebook.com%2Frarathemehq&amp;locale=en_US&amp;sdk=joey&amp;show_facepile=true&amp;small_header=true&amp;tabs=timeline&amp;width=400" style="border: none; visibility: visible; width: 380px; height: 300px;" class=""></iframe></span>
						</div>
					</div>

				</section>
			</div>
			<div class="col">
				<section id="text-3" class="widget widget_text"><h2 class="widget-title">Visit us anytime between</h2>			
					<div class="textwidget">
						<table>
							<tbody>
								<tr>
									<td><b>Sunday<b></b></b></td>
									<td>9:00 PM to 7:00 PM</td>
								</tr>
								<tr>
									<td><b>Monday<b></b></b></td>
									<td>9:00 AM to 7:00 PM</td>
								</tr>
								<tr>
									<td><b>Tuesday<b></b></b></td>
									<td>9:00 AM to 7:00 PM</td>
								</tr>
								<tr>
									<td><b>Wednesday<b></b></b></td>
									<td>9:00 AM to 7:00 PM</td>
								</tr>
								<tr>
									<td><b>Thursday<b></b></b></td>
									<td>9:00 AM to 7:00 PM</td>
								</tr>
								<tr>
									<td><b>Friday<b></b></b></td>
									<td>9:00 AM to 7:00 PM</td>
								</tr>
								<tr>
									<td><b>Saturday<b></b></b></td>
									<td>1:00 PM to 7:00 PM</td>
								</tr>
							</tbody>
						</table>
					</div>
				</section>
				<section id="spa_and_salon_social_links-4" class="widget widget_spa_and_salon_social_links">
					<h2 class="widget-title">Connect with us</h2>
					<ul class="social-networks">
						<li><a href="#" target="_blank" title="Facebook" class="fa fa-facebook"></a></li>
						<li><a href="#" target="_blank" title="Twitter" class="fa fa-twitter"></a></li>
						<li><a href="#" target="_blank" title="Instagram" class="fa fa-instagram"></a></li>
						<li><a href="#" target="_blank" title="Gooble Plus" class="fa fa-google-plus"></a></li>
						<li><a href="#" target="_blank" title="Pinterest" class="fa fa-pinterest-p"></a></li>
						<li><a href="#" target="_blank" title="Dribbble" class="fa fa-dribbble"></a></li>
						<li><a href="#" title="Skype" class="fa fa-skype"></a></li>
						<li><a href="#" target="_blank" title="StumbleUpon" class="fa fa-stumbleupon"></a></li>
						<li><a href="#" target="_blank" title="Tumblr" class="fa fa-tumblr"></a></li>
					</ul>
				</section>
			</div>				
		</div>
	</div>
</div>