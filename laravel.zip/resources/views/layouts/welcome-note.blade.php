<section class="welcome-note" id="welcome-note">
	<div class="container">
		<div class="row">
			<div class="col left-col">
				<img src="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/wellness-589775_640.jpg" alt="About Spa and Salon Theme" scale="0">
			</div>
			<div class="col">
				<h2 class="title">About Spa and Salon Theme</h2>
				<p></p><p>Massage involves working and acting on the body with pressure – structured, unstructured, stationary, or moving – tension, motion, or vibration, done manually or with mechanical aids. Massage can be applied with the hands, fingers, elbows, knees, forearm, feet, or a massage device. Depending on the application and technique used, massage is used to promote relaxation and well-being, and is beneficial in treating sports injuries.</p>
				<p></p>
				<a href="https://raratheme.com/preview/spa-and-salon-pro/about-us/" class="btn-green">Read More</a>
			</div>
		</div>
	</div>
</section>