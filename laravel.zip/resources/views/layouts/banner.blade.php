<div class="banner">
  <div id="banner-slider" class="banner-carousel owl-carousel owl-theme owl-loaded">	
    
    
      <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(0px, 0px, 0px); transition: 0s; width: 3166px;"><div class="owl-item active" style="width: 1583px;"><div>
          <img width="1920" height="967" src="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1.jpg" class="attachment-spa-and-salon-slider size-spa-and-salon-slider wp-post-image" alt="" srcset="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1.jpg 1920w, https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1-300x151.jpg 300w, https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1-768x387.jpg 768w, https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1-1024x516.jpg 1024w" sizes="(max-width: 1920px) 100vw, 1920px" data-attachment-id="384" data-permalink="https://raratheme.com/preview/spa-and-salon-pro/spa-and-massage/spa-and-salon-pro-theme-1/" data-orig-file="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1.jpg" data-orig-size="1920,967" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;0&quot;,&quot;iso&quot;:&quot;0&quot;,&quot;shutter_speed&quot;:&quot;0&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;0&quot;}" data-image-title="spa-and-salon-pro-theme-1" data-image-description="" data-medium-file="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1-300x151.jpg" data-large-file="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-Pro-theme-1-1024x516.jpg">                        
          
          <div class="banner-text">
            <div class="container">
                <div class="text">
                    <strong class="title">Spa and Massage</strong>
                    <p>Experience the Art of Caring</p>
                    <a href="https://raratheme.com/preview/spa-and-salon-pro/spa-and-massage/" class="btn-green">Read More</a>
                </div>
            </div>
        </div>
        
    </div></div><div class="owl-item" style="width: 1583px;"><div>
    <img width="1920" height="967" src="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1.jpg" class="attachment-spa-and-salon-slider size-spa-and-salon-slider wp-post-image" alt="" srcset="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1.jpg 1920w, https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1-300x151.jpg 300w, https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1-768x387.jpg 768w, https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1-1024x516.jpg 1024w" sizes="(max-width: 1920px) 100vw, 1920px" data-attachment-id="203" data-permalink="https://raratheme.com/preview/spa-and-salon-pro/peaceful-and-serene-environment/spa-and-salon-wordpress-theme-1/" data-orig-file="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1.jpg" data-orig-size="1920,967" data-comments-opened="1" data-image-meta="{&quot;aperture&quot;:&quot;0&quot;,&quot;credit&quot;:&quot;&quot;,&quot;camera&quot;:&quot;&quot;,&quot;caption&quot;:&quot;&quot;,&quot;created_timestamp&quot;:&quot;0&quot;,&quot;copyright&quot;:&quot;&quot;,&quot;focal_length&quot;:&quot;0&quot;,&quot;iso&quot;:&quot;0&quot;,&quot;shutter_speed&quot;:&quot;0&quot;,&quot;title&quot;:&quot;&quot;,&quot;orientation&quot;:&quot;0&quot;}" data-image-title="spa-and-salon-wordpress-theme-1" data-image-description="" data-medium-file="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1-300x151.jpg" data-large-file="https://raratheme.com/preview/spa-and-salon-pro/wp-content/uploads/2016/11/Spa-and-Salon-WordPress-theme-1-1024x516.jpg">                        
    
    <div class="banner-text">
        <div class="container">
            <div class="text">
                <strong class="title">Peaceful &amp; Serene</strong>
                <p>Our venue is calm and serene.</p>
                <a href="https://raratheme.com/preview/spa-and-salon-pro/peaceful-and-serene-environment/" class="btn-green">Read More</a>
            </div>
        </div>
    </div>
    
</div></div></div></div><div class="owl-nav"><div class="owl-prev disabled">prev</div><div class="owl-next">next</div></div><div class="owl-dots"><div class="owl-dot active"><span></span></div><div class="owl-dot"><span></span></div></div></div>
</div>